# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###
Client side of the Tree Home Manager project. Uses kivy framework to boost its capabilities GUI wise.
IoT Software to be truly the owner your house deserves.

### How do I get set up? ###
There's currently no working build.

### Contribution guidelines ###
Code Reviewers needed.

### Who do I talk to? ###
tatanpoker09 is the currently the only person working in this project.