class FileStorage:
    def __init__(self):
        pass
    def save(self):
        pass
