class ThreadedClient(object):
    def __init__(self, host, port):
        pass

    def start(self):
        pass