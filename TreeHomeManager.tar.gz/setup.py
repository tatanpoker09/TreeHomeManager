from distutils.core import setup

setup(
    name='treehomemanager-v2',
    version='',
    packages=['main', 'main.modules', 'main.modules.lights', 'main.modules.cameras', 'main.GUI', 'main.GUI.loading', 'main.GUI.loginscreen', 'main.GUI.mainmenu'],
    url='',
    license='',
    author='tatanpoker09',
    author_email='',
    description=''
)
